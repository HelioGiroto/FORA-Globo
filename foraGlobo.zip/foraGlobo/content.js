let url = window.location.href 
if(url.match(/globo.com/g)){
	// alert('ALERTA! SITE DE FAKE NEWS!')
	document.write('<br><br><center><h1>FAKE NEWS DETECTADAS!!<br>Site da Globo bloqueado!</h1></center>')
}

// Autor: H. Giroto
